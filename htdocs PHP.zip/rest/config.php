<?php

$db = [
    'host' => 'localhost',
    'username' => 'miguel',
    'password' => 'miguel',
    'db' => 'usuarios' //Cambiar al nombre de tu base de datos
];

?>
