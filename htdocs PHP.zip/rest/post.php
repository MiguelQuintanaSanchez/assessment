<?php
error_reporting(-1);

if (isset($_SERVER['HTTP_ORIGIN'])) {
  // Decide if the origin in $_SERVER['HTTP_ORIGIN'] is one
  // you want to allow, and if so:
  header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
  header('Access-Control-Allow-Credentials: true');
  header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

  if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
      header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");         

  if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
      header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

  exit(0);
}

include "config.php";
include "utils.php";

$dbConn =  connect($db);
/*
  listar todos los posts o solo uno
 */
if ($_SERVER['REQUEST_METHOD'] == 'GET')
{
    if (isset($_GET['folio']))
    {
      //Mostrar un post
      $sql = $dbConn->prepare("SELECT * FROM usuario where folio=:folio");
      $sql->bindValue(':folio', $_GET['folio']);
      $sql->execute();
      header("HTTP/1.1 200 OK");
      echo json_encode(  $sql->fetch(PDO::FETCH_ASSOC)  );
      exit();
	  } else if(isset($_GET['ultimo']) ){
      $sql = $dbConn->prepare("SELECT * FROM usuario where folio>:folio AND eliminado=0 limit 20");
      $sql->bindValue(':folio', $_GET['ultimo']);
      $sql->execute();
      header("HTTP/1.1 200 OK");
      echo json_encode(  $sql->fetchAll()  );
      exit();
    } else if(isset($_GET['total'])){
      $sql = $dbConn->prepare("SELECT COUNT(folio) FROM usuario;");
      $sql->execute();
      $sql->setFetchMode(PDO::FETCH_ASSOC);
      header("HTTP/1.1 200 OK");
      echo json_encode( $sql->fetchAll()  );
      exit();
    }
    else {
      //Mostrar lista de post
      $sql = $dbConn->prepare("SELECT * FROM usuario");
      $sql->execute();
      $sql->setFetchMode(PDO::FETCH_ASSOC);
      header("HTTP/1.1 200 OK");
      echo json_encode( $sql->fetchAll()  );
      exit();
	}
}

// Crear un nuevo post
if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
    $input = $_REQUEST;
    if(isset($input['nombre'])&&isset($input['apellido'])&&isset($input['fecha_de_nacimiento'])&&isset($input['email'])&&no_vacios($input)){
      $sql = "INSERT INTO usuario
            (nombre, apellido, fecha_de_nacimiento, telefono, email, calle, numero, colonia, ciudad, codigo_postal)
            VALUES
            (:nombre, :apellido, :fecha_de_nacimiento, :telefono, :email, :calle, :numero, :colonia, :ciudad, :codigo_postal)";
      $statement = $dbConn->prepare($sql);
      bindAllValues($statement, $input);
      $statement->execute();
      $postId = $dbConn->lastInsertId();
      if($postId)
      {
        $input['id'] = $postId;
        header("HTTP/1.1 200 OK");
        echo json_encode($input);
        exit();
	    }
    }
}


//Actualizar
if ($_SERVER['REQUEST_METHOD'] == 'PUT')
{ 
  $sql = "UPDATE usuario SET eliminado=".$_REQUEST['eliminado']." where folio=".$_REQUEST['folio'];
  $statement = $dbConn->prepare($sql);
  
  $statement->execute();
  header("HTTP/1.1 200 OK");
  exit();
}

function no_vacios($input){
  return $input['nombre']!="" && $input['apellido']!="" && $input['fecha_de_nacimiento']!="" && $input['email']!='';
}

//En caso de que ninguna de las opciones anteriores se haya ejecutado
header("HTTP/1.1 400 Bad Request");

?>